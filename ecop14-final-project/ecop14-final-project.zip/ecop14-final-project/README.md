Arquivos ralativos ao projeto final da disciplina de ECOP14 - Laboratório de Programação Embarcada da Universidade Federal de Itajubá (UNIFEI), foi elaborado um controlador de superfíces de voo.
